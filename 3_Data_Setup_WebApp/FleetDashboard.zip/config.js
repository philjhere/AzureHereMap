var config = {}

config.endpoint = "";       //Cosmos DB URI
config.primaryKey = "";     //Cosmos DB PRIMARY KEY

config.database = {
    "id": "HERE_API_LOGS"
};

config.container = {
    "id": "here_api_logs"
};



module.exports = config;